# HAR Logging for Debugging Login Issues

## Oversigt
HAR (HTTP Archive) logging er tilføjet til DMP Manager plugin for at hjælpe med at diagnosticere login-problemer mellem DEMO og produktionsmiljøer.

## Hvad er en HAR fil?
En HAR (HTTP Archive) fil er et JSON-formateret arkiv der indeholder en detaljeret log af alle HTTP requests og responses. Den kan bruges til at:
- Debugge login-problemer
- Analysere netværkstrafik
- Identificere forskelle mellem DEMO og produktion
- Dele detaljerede tekniske oplysninger med support

## Hvordan aktiverer man HAR logging?

### Trin 1: Åbn configuration.json
Åbn filen: `dmp_manager/configuration.json`

### Trin 2: Aktiver HAR logging
Find den relevante konfiguration (`mp_demo` eller `mp_produktion`) og sæt `enableHarLogging` til `true`:

```json
{
    "Access": {
        "mp_produktion": {
            "Name": "Miljøportalen-PROD",
            ...
            "enableHarLogging": true
        }
    }
}
```

### Trin 3: Genstart QGIS
Luk og genstart QGIS for at indlæse den nye konfiguration.

### Trin 4: Forsøg login
Når du logger ind, vil alle HTTP requests blive fanget og gemt.

## Hvor gemmes HAR filerne?

HAR filer gemmes i mappen: `dmp_manager/har_logs/`

Filnavne følger dette format:
- **Vellykket login:** `har_login_{miljø}_{timestamp}.har`
- **Redirect fejl (ingen authorization code):** `har_redirect_failed_{miljø}_{timestamp}.har`
- **Token exchange fejl:** `har_error_{miljø}_{timestamp}.har`
- **Token exchange exception:** `har_exception_{miljø}_{timestamp}.har`
- **Token refresh fejl:** `har_refresh_error_{miljø}_{timestamp}.har`
- **Token refresh exception:** `har_refresh_exception_{miljø}_{timestamp}.har`

Eksempel: `har_redirect_failed_mp_produktion_20260225_143022.har`

## Sådan deler du HAR filen med support

1. Find HAR filen i `dmp_manager/har_logs/` mappen
2. Send filen til support via email eller ticket system
3. **VIGTIGT:** HAR filer kan indeholde følsomme data (tokens, passwords, etc.)
   - Tjek filen før afsendelse hvis du er bekymret for sikkerhed
   - Overvej at sende via sikker kanal

## Sådan læser/analyserer man en HAR fil

HAR filer kan åbnes med:
- **Chrome DevTools:** Open DevTools → Network tab → Right-click → "Import HAR file"
- **Firefox DevTools:** Network tab → Gear icon → "Import HAR"
- **Online tools:** https://toolbox.googleapps.com/apps/har_analyzer/
- **Tekst editor:** HAR er JSON-format og kan læses direkte

## Eksempel på HAR fil indhold

```json
{
  "log": {
    "version": "1.2",
    "creator": {
      "name": "QGIS DMP Manager Plugin",
      "version": "1.0"
    },
    "entries": [
      {
        "request": {
          "method": "POST",
          "url": "https://log-in.miljoeportal.dk/runtime/oauth2/token.idp",
          "headers": [...],
          "postData": {...}
        },
        "response": {
          "status": 400,
          "statusText": "Bad Request",
          "headers": [...],
          "content": {...}
        }
      }
    ]
  }
}
```

## Tips til debugging

1. **Sammenlign DEMO vs PROD:**
   - Aktiver HAR logging for begge miljøer
   - Log ind i begge
   - Sammenlign de genererede HAR filer

2. **Tjek status codes:**
   - 200 = Success
   - 400 = Bad Request (ofte konfigurationsfejl)
   - 401 = Unauthorized (token/authentication fejl)
   - 403 = Forbidden (permissions fejl)
   - 500 = Server Error

3. **Vigtige felter at tjekke:**
   - `request.url` - Er URL'en korrekt?
   - `request.postData.params` - Er alle parametre korrekte?
   - `response.status` - Hvad siger serveren?
   - `response.content.text` - Fejlmeddelelser fra serveren

## Deaktivering af HAR logging

Når debugging er færdig, husk at deaktivere HAR logging:

1. Sæt `enableHarLogging` til `false` i `configuration.json`
2. Genstart QGIS
3. (Valgfrit) Ryd op i `har_logs/` mappen

## Sikkerhedsovervejelser

⚠️ **ADVARSEL:** HAR filer kan indeholde følsomme oplysninger:
- Access tokens
- Refresh tokens
- Client IDs
- Brugeroplysninger

**Anbefalinger:**
- Aktiver kun HAR logging når det er nødvendigt
- Slet HAR filer efter brug
- Vær forsigtig med at dele HAR filer offentligt
- Hvis du skal dele med support, send via sikker kanal

## Fejlfinding

**Problem:** Ingen HAR fil genereres
- **Løsning:** Tjek at `enableHarLogging` er sat til `true` og QGIS er genstartet

**Problem:** Kan ikke finde `har_logs` mappen
- **Løsning:** Mappen oprettes automatisk første gang HAR logging er aktiveret og et login-forsøg udføres

**Problem:** HAR filen er tom
- **Løsning:** Dette kan ske hvis der ikke blev foretaget nogen HTTP requests. Prøv at logge ind igen.
