"""
/***************************************************************************
HAR (HTTP Archive) Logger for debugging HTTP requests
Captures HTTP requests and responses in HAR format for debugging

        copyright            : (C) 2026 by Morten Fuglsang, Septima
        email                : morten.fuglsang@septima.dk
 ***************************************************************************/
"""

import json
import os
from datetime import datetime
from typing import Optional


class HarLogger:
    """Logger that captures HTTP requests and responses in HAR format"""
    
    def __init__(self, enabled=False, output_dir=None):
        """
        Initialize HAR logger
        
        Args:
            enabled: Whether HAR logging is enabled
            output_dir: Directory to save HAR files. If None, uses temp directory
        """
        self.enabled = enabled
        self.entries = []
        self.output_dir = output_dir or os.path.join(os.path.dirname(__file__), 'har_logs')
        
        if self.enabled:
            os.makedirs(self.output_dir, exist_ok=True)
    
    def log_request(self, method, url, headers=None, data=None, response=None, error=None, duration_ms=0):
        """
        Log a single HTTP request/response
        
        Args:
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            headers: Request headers dict
            data: Request data/body
            response: Response object (from requests library)
            error: Error message if request failed
            duration_ms: Request duration in milliseconds
        """
        if not self.enabled:
            return
        
        # Build request entry
        entry = {
            "startedDateTime": datetime.utcnow().isoformat() + "Z",
            "time": duration_ms,
            "request": self._build_request_entry(method, url, headers, data),
            "response": self._build_response_entry(response, error) if response or error else {},
            "cache": {},
            "timings": {
                "send": 0,
                "wait": duration_ms,
                "receive": 0
            }
        }
        
        self.entries.append(entry)
    
    def _build_request_entry(self, method, url, headers, data):
        """Build HAR request entry"""
        request_headers = []
        if headers:
            for name, value in headers.items():
                request_headers.append({"name": name, "value": str(value)})
        
        # Build query string
        query_string = []
        if '?' in url:
            query_part = url.split('?', 1)[1]
            for param in query_part.split('&'):
                if '=' in param:
                    key, value = param.split('=', 1)
                    query_string.append({"name": key, "value": value})
        
        # Build post data
        post_data = {}
        if data:
            if isinstance(data, dict):
                params = []
                for key, value in data.items():
                    params.append({"name": key, "value": str(value)})
                post_data = {
                    "mimeType": "application/x-www-form-urlencoded",
                    "params": params
                }
            else:
                post_data = {
                    "mimeType": "text/plain",
                    "text": str(data)
                }
        
        request_entry = {
            "method": method,
            "url": url,
            "httpVersion": "HTTP/1.1",
            "headers": request_headers,
            "queryString": query_string,
            "cookies": [],
            "headersSize": -1,
            "bodySize": len(str(data)) if data else 0
        }
        
        if post_data:
            request_entry["postData"] = post_data
        
        return request_entry
    
    def _build_response_entry(self, response, error):
        """Build HAR response entry"""
        if error:
            return {
                "status": 0,
                "statusText": str(error),
                "httpVersion": "HTTP/1.1",
                "headers": [],
                "cookies": [],
                "content": {
                    "size": 0,
                    "mimeType": "text/plain",
                    "text": str(error)
                },
                "redirectURL": "",
                "headersSize": -1,
                "bodySize": 0
            }
        
        # Build response headers
        response_headers = []
        if hasattr(response, 'headers'):
            for name, value in response.headers.items():
                response_headers.append({"name": name, "value": str(value)})
        
        # Get response content
        content_text = ""
        content_size = 0
        mime_type = "text/plain"
        
        if hasattr(response, 'text'):
            content_text = response.text
            content_size = len(content_text)
        
        if hasattr(response, 'headers') and 'content-type' in response.headers:
            mime_type = response.headers['content-type']
        
        return {
            "status": response.status_code if hasattr(response, 'status_code') else 0,
            "statusText": response.reason if hasattr(response, 'reason') else "",
            "httpVersion": "HTTP/1.1",
            "headers": response_headers,
            "cookies": [],
            "content": {
                "size": content_size,
                "mimeType": mime_type,
                "text": content_text
            },
            "redirectURL": "",
            "headersSize": -1,
            "bodySize": content_size
        }
    
    def save(self, filename=None):
        """
        Save captured requests to HAR file
        
        Args:
            filename: Optional filename. If not provided, generates timestamp-based name
            
        Returns:
            Path to saved HAR file
        """
        if not self.enabled or not self.entries:
            return None
        
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"har_log_{timestamp}.har"
        
        filepath = os.path.join(self.output_dir, filename)
        
        har_data = {
            "log": {
                "version": "1.2",
                "creator": {
                    "name": "QGIS DMP Manager Plugin",
                    "version": "1.0"
                },
                "entries": self.entries
            }
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(har_data, f, indent=2, ensure_ascii=False)
        
        return filepath
    
    def clear(self):
        """Clear all logged entries"""
        self.entries = []
